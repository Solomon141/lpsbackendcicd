from django.apps import AppConfig


class WithdrawaldetailConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'withdrawaldetail'
